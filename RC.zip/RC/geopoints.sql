-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Tempo de geração: 16-Mar-2026 às 08:20
-- Versão do servidor: 11.5.2-MariaDB
-- versão do PHP: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `geopoints`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `localizacoes`
--

DROP TABLE IF EXISTS `localizacoes`;
CREATE TABLE IF NOT EXISTS `localizacoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) NOT NULL,
  `pais` varchar(100) NOT NULL,
  `cidade` varchar(100) NOT NULL,
  `tipo` varchar(50) NOT NULL DEFAULT 'Outro',
  `latitude` decimal(10,7) NOT NULL,
  `longitude` decimal(10,7) NOT NULL,
  `descricao` text DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `atualizado_em` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_pais` (`pais`),
  KEY `idx_cidade` (`cidade`),
  KEY `idx_tipo` (`tipo`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `localizacoes`
--

INSERT INTO `localizacoes` (`id`, `nome`, `pais`, `cidade`, `tipo`, `latitude`, `longitude`, `descricao`, `user_id`, `criado_em`, `atualizado_em`) VALUES
(1, 'Aeroporto Humberto Delgado', 'Portugal', 'Lisboa', 'Aeroporto', 38.7742000, -9.1342000, 'Principal aeroporto internacional de Portugal.', 1, '2026-03-14 19:48:52', '2026-03-14 19:48:52'),
(2, 'Hospital de Santa Maria', 'Portugal', 'Lisboa', 'Hospital', 38.7484000, -9.1603000, 'Hospital universitario e centro de referencia nacional.', 1, '2026-03-14 19:48:52', '2026-03-14 19:48:52'),
(3, 'Museu do Louvre', 'Franca', 'Paris', 'Museu', 48.8606000, 2.3376000, 'O maior museu de arte do mundo.', 2, '2026-03-14 19:48:52', '2026-03-14 19:48:52'),
(4, 'Aeroporto Charles de Gaulle', 'Franca', 'Paris', 'Aeroporto', 49.0097000, 2.5479000, 'Principal aeroporto internacional de Paris.', 1, '2026-03-14 19:48:52', '2026-03-14 19:48:52'),
(5, 'Parque Eduardo VII', 'Portugal', 'Lisboa', 'Parque', 38.7263000, -9.1524000, 'Parque urbano no coracao de Lisboa.', 2, '2026-03-14 19:48:52', '2026-03-14 19:48:52'),
(6, 'Estacao de Sao Bento', 'Portugal', 'Porto', 'Estacao', 41.1459000, -8.6097000, 'Famosa pelos azulejos na entrada.', 3, '2026-03-14 19:48:52', '2026-03-14 19:48:52'),
(7, 'Aeroporto Francisco Sa Carneiro', 'Portugal', 'Porto', 'Aeroporto', 41.2355000, -8.6784000, 'Aeroporto internacional do Porto.', 1, '2026-03-14 19:48:52', '2026-03-14 19:48:52'),
(8, 'Coliseu do Porto', 'Portugal', 'Porto', 'Museu', 41.1494000, -8.6091000, 'Sala de espetaculos historica no centro do Porto.', 3, '2026-03-14 19:48:52', '2026-03-14 19:48:52');

-- --------------------------------------------------------

--
-- Estrutura da tabela `utilizadores`
--

DROP TABLE IF EXISTS `utilizadores`;
CREATE TABLE IF NOT EXISTS `utilizadores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `role` varchar(10) NOT NULL DEFAULT 'user',
  `criado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `ultimo_login` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `utilizadores`
--

INSERT INTO `utilizadores` (`id`, `username`, `password`, `nome`, `role`, `criado_em`, `ultimo_login`) VALUES
(1, 'admin', 'admin123', 'Administrador', 'admin', '2026-03-14 19:48:52', NULL),
(2, 'user1', 'user123', 'Joao Silva', 'user', '2026-03-14 19:48:52', NULL),
(3, 'user2', 'user456', 'Maria Santos', 'user', '2026-03-14 19:48:52', NULL);

-- --------------------------------------------------------

--
-- Estrutura stand-in para vista `v_localizacoes`
-- (Veja abaixo para a view atual)
--
DROP VIEW IF EXISTS `v_localizacoes`;
CREATE TABLE IF NOT EXISTS `v_localizacoes` (
`id` int(11)
,`nome` varchar(150)
,`pais` varchar(100)
,`cidade` varchar(100)
,`tipo` varchar(50)
,`latitude` decimal(10,7)
,`longitude` decimal(10,7)
,`descricao` text
,`criado_em` datetime
,`atualizado_em` datetime
,`user_id` int(11)
,`user_username` varchar(50)
,`user_nome` varchar(100)
,`user_role` varchar(10)
);

-- --------------------------------------------------------

--
-- Estrutura para vista `v_localizacoes`
--
DROP TABLE IF EXISTS `v_localizacoes`;

DROP VIEW IF EXISTS `v_localizacoes`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_localizacoes`  AS SELECT `l`.`id` AS `id`, `l`.`nome` AS `nome`, `l`.`pais` AS `pais`, `l`.`cidade` AS `cidade`, `l`.`tipo` AS `tipo`, `l`.`latitude` AS `latitude`, `l`.`longitude` AS `longitude`, `l`.`descricao` AS `descricao`, `l`.`criado_em` AS `criado_em`, `l`.`atualizado_em` AS `atualizado_em`, `u`.`id` AS `user_id`, `u`.`username` AS `user_username`, `u`.`nome` AS `user_nome`, `u`.`role` AS `user_role` FROM (`localizacoes` `l` join `utilizadores` `u` on(`u`.`id` = `l`.`user_id`)) ;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `localizacoes`
--
ALTER TABLE `localizacoes`
  ADD CONSTRAINT `fk_loc_user` FOREIGN KEY (`user_id`) REFERENCES `utilizadores` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
